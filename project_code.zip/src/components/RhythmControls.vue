<template>
  <div class="rhythm-controls">
    <div class="section-label">RHYTHM</div>
    
    <div class="main-row">
        <button 
            class="btn-rhythm" 
            :class="{ active: isPlaying }"
            @click="toggleRhythm"
        >
            <span class="icon">{{ isPlaying ? '■' : '▶' }}</span>
        </button>

        <div class="params-col">
            <select v-model="selectedPattern" @change="updatePattern" class="pattern-select">
                <option value="ROCK">ROCK</option>
                <option value="TECHNO">TECHNO</option>
                <option value="METRONOME">METRO</option>
            </select>
            
            <div class="level-control">
                <span class="sub-label">VOL</span>
                <input 
                    type="range" 
                    min="0" 
                    max="100" 
                    v-model.number="volume" 
                    @input="updateVolume"
                    class="level-slider"
                />
            </div>
        </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue';
import { AudioEngine } from '../audio/AudioEngine';
import type { RhythmPattern } from '../audio/RhythmEngine';

const engine = AudioEngine.getInstance();
const isPlaying = ref(false);
const selectedPattern = ref<RhythmPattern>('ROCK');
const volume = ref(50);

const toggleRhythm = () => {
    if (isPlaying.value) {
        engine.rhythmEngine.stop();
        isPlaying.value = false;
    } else {
        engine.rhythmEngine.start();
        isPlaying.value = true;
    }
};

const updatePattern = () => {
    engine.rhythmEngine.setPattern(selectedPattern.value);
};

const updateVolume = () => {
    engine.rhythmEngine.setVolume(volume.value);
};

onMounted(() => {
    // Initialize
    engine.rhythmEngine.setVolume(volume.value);
    engine.rhythmEngine.setPattern(selectedPattern.value);
});
</script>

<style scoped>
.rhythm-controls {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  padding: 0 12px;
  border-left: 1px solid #333;
  border-right: 1px solid #333;
}

.section-label {
  font-family: var(--font-hardware);
  font-size: 12px;
  color: #666;
  letter-spacing: 2px;
  font-weight: 700;
}

.main-row {
    display: flex;
    gap: 12px;
    align-items: center;
}

.btn-rhythm {
    width: 48px;
    height: 48px;
    border-radius: 50%;
    background: #222;
    border: 2px solid #444;
    color: #888;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.2s;
    box-shadow: 0 4px 8px rgba(0,0,0,0.3);
}

.btn-rhythm:hover {
    border-color: #666;
    color: #fff;
}

.btn-rhythm.active {
    background: #ff3333;
    border-color: #ff6666;
    color: #fff;
    box-shadow: 0 0 15px rgba(255, 51, 51, 0.4);
}

.icon {
    font-size: 18px;
}

.params-col {
    display: flex;
    flex-direction: column;
    gap: 6px;
}

.pattern-select {
    background: #111;
    color: #0ff;
    border: 1px solid #333;
    padding: 2px 6px;
    font-family: var(--font-mono);
    font-size: 11px;
    border-radius: 4px;
    outline: none;
    cursor: pointer;
    text-transform: uppercase;
    width: 80px;
}

.pattern-select:hover {
    border-color: #0ff;
}

.level-control {
    display: flex;
    align-items: center;
    gap: 6px;
}

.sub-label {
    font-size: 9px;
    color: #555;
    font-weight: bold;
}

.level-slider {
    width: 55px;
    height: 4px;
    -webkit-appearance: none;
    appearance: none;
    background: #333;
    border-radius: 2px;
    outline: none;
}

.level-slider::-webkit-slider-thumb {
    -webkit-appearance: none;
    width: 10px;
    height: 10px;
    border-radius: 50%;
    background: #888;
    cursor: pointer;
    transition: background 0.2s;
}

.level-slider::-webkit-slider-thumb:hover {
    background: #fff;
}
</style>
