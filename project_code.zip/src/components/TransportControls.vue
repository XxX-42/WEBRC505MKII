<template>
  <div class="transport-bar">
    <!-- BPM Display Section (7-Segment LED Style) -->
    <div class="bpm-module">
      <div class="module-label">TEMPO</div>
      <div class="led-display-container">
        <div class="led-display">
          <span class="led-digits">{{ bpmDisplay }}</span>
        </div>
        <div class="bpm-controls">
          <button @click="adjustBpm(-1)" class="bpm-adjust-btn">
            <span>−</span>
          </button>
          <button @click="adjustBpm(1)" class="bpm-adjust-btn">
            <span>+</span>
          </button>
        </div>
      </div>
    </div>

    <!-- Divider -->
    <div class="divider"></div>

    <!-- Global Transport Controls -->
    <div class="transport-controls">
      <HardwareButton
        size="lg"
        :color="isPlaying ? 'red' : 'green'"
        :active="isPlaying"
        :label="isPlaying ? 'STOP ALL' : 'PLAY ALL'"
        @press="toggleTransport"
        class="transport-button"
      />
      
      <HardwareButton
        size="sm"
        color="blue"
        :active="tapActive"
        label="TAP"
        @press="handleTap"
        class="tap-button"
      />
    </div>

    <!-- Divider -->
    <div class="divider"></div>

    <!-- Beat Indicator -->
    <div class="beat-indicator-module">
      <div class="module-label">BEAT</div>
      <div class="beat-led" :class="{ active: beatIndicator }"></div>
    </div>

    <!-- Divider -->
    <div class="divider"></div>

    <!-- THRU Button (Direct Monitoring) -->
    <div class="thru-module">
      <HardwareButton
        size="sm"
        color="red"
        :active="isThruActive"
        label="THRU"
        @press="toggleThru"
        class="thru-button"
      />
    </div>

    <!-- Divider -->
    <div class="divider"></div>

    <!-- Settings Button -->
    <div class="settings-module">
      <HardwareButton
        size="md"
        color="white"
        label="⚙️ SETTINGS"
        @press="openSettings"
        class="settings-button"
      />
    </div>

    <!-- Audio Settings Modal -->
    <AudioSettings v-model="showSettings" />
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue';
import { Transport } from '../core/Transport';
import { TransportState } from '../core/types';
import { AudioEngine } from '../audio/AudioEngine';
import HardwareButton from './ui/HardwareButton.vue';
import AudioSettings from './AudioSettings.vue';

const transport = Transport.getInstance();
const engine = AudioEngine.getInstance();

const bpm = ref(transport.bpm);
const isPlaying = ref(false);
const beatIndicator = ref(false);
const tapActive = ref(false);
const showSettings = ref(false);
const isThruActive = ref(engine.monitoringEnabled);

// Format BPM for 7-segment display (always 3 digits)
const bpmDisplay = computed(() => {
  return bpm.value.toString().padStart(3, '0');
});

const updateState = () => {
  bpm.value = transport.bpm;
  isPlaying.value = transport.state === TransportState.PLAYING;
};

const adjustBpm = (delta: number) => {
  const newBpm = Math.max(40, Math.min(300, transport.bpm + delta));
  transport.setBpm(newBpm);
  updateState();
};

const toggleTransport = () => {
  if (transport.state === TransportState.PLAYING) {
    transport.stop();
  } else {
    transport.start();
  }
  updateState();
};

const openSettings = () => {
  showSettings.value = true;
};

/**
 * Toggle THRU (Direct Monitoring)
 * CRITICAL SAFETY: Confirms with user before enabling to prevent feedback
 */
const toggleThru = () => {
  if (!isThruActive.value) {
    // ENABLING monitoring - show safety warning
    const confirmed = confirm(
      '⚠️ WARNING: FEEDBACK RISK!\n\n' +
      'Enabling THRU will route your microphone directly to speakers.\n\n' +
      'This will cause LOUD SQUEALING/HOWLING if you are using speakers!\n\n' +
      'Only proceed if you are using HEADPHONES.\n\n' +
      'Enable THRU?'
    );
    
    if (confirmed) {
      engine.setMonitoring(true);
      isThruActive.value = true;
      console.log('🎧 THRU ENABLED - Monitoring active (USE HEADPHONES!)');
    }
  } else {
    // DISABLING monitoring - safe, no confirmation needed
    engine.setMonitoring(false);
    isThruActive.value = false;
    console.log('🔇 THRU DISABLED - Monitoring off (SAFE)');
  }
};

// Tap tempo functionality (placeholder)
let tapTimes: number[] = [];
const handleTap = () => {
  tapActive.value = true;
  setTimeout(() => tapActive.value = false, 100);
  
  const now = Date.now();
  tapTimes.push(now);
  
  // Keep only last 4 taps
  if (tapTimes.length > 4) {
    tapTimes.shift();
  }
  
  // Calculate BPM from taps
  if (tapTimes.length >= 2) {
    const intervals = [];
    for (let i = 1; i < tapTimes.length; i++) {
      intervals.push(tapTimes[i] - tapTimes[i - 1]);
    }
    const avgInterval = intervals.reduce((a, b) => a + b, 0) / intervals.length;
    const calculatedBpm = Math.round(60000 / avgInterval);
    
    if (calculatedBpm >= 40 && calculatedBpm <= 300) {
      transport.setBpm(calculatedBpm);
      updateState();
    }
  }
  
  // Reset if no tap for 3 seconds
  setTimeout(() => {
    if (tapTimes.length > 0 && Date.now() - tapTimes[tapTimes.length - 1] > 3000) {
      tapTimes = [];
    }
  }, 3000);
};

// Event Listeners
const onTick = () => {
  beatIndicator.value = true;
  setTimeout(() => beatIndicator.value = false, 100);
};

onMounted(() => {
  transport.on('start', updateState);
  transport.on('stop', updateState);
  transport.on('bpm-change', updateState);
  transport.on('tick', onTick);
});
</script>

<style scoped>
/* ========================================
   TRANSPORT BAR CONTAINER
   ======================================== */

.transport-bar {
  display: flex;
  align-items: center;
  gap: 24px;
  padding: 16px 24px;
  
  /* Hardware panel styling */
  background: var(--bg-panel-secondary);
  border: 2px solid #0d0d0d;
  border-radius: var(--border-radius-hardware);
  
  /* Multi-layer shadow */
  box-shadow: 
    inset 0 1px 0 rgba(255, 255, 255, 0.03),
    inset 0 -1px 0 rgba(0, 0, 0, 0.8),
    0 4px 12px rgba(0, 0, 0, 0.8);
}

/* Divider */
.divider {
  width: 2px;
  height: 48px;
  background: linear-gradient(
    180deg,
    transparent 0%,
    rgba(255, 255, 255, 0.1) 50%,
    transparent 100%
  );
}

/* ========================================
   BPM MODULE (7-Segment LED Display)
   ======================================== */

.bpm-module {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.module-label {
  font-size: 9px;
  font-weight: 700;
  letter-spacing: 1.5px;
  color: rgba(240, 240, 240, 0.4);
  font-family: var(--font-mono);
  text-align: center;
  text-transform: uppercase;
  text-shadow: 0 1px 0 rgba(0, 0, 0, 0.6);
}

.led-display-container {
  display: flex;
  align-items: center;
  gap: 8px;
}

/* 7-Segment LED Display */
.led-display {
  position: relative;
  padding: 12px 20px;
  background: #0a0000;
  border: 2px solid #1a0000;
  border-radius: 4px;
  
  /* Inset shadow for depth */
  box-shadow: 
    inset 0 2px 6px rgba(0, 0, 0, 0.9),
    inset 0 -1px 2px rgba(255, 0, 0, 0.05),
    0 0 8px rgba(255, 0, 0, 0.1);
}

.led-digits {
  font-family: 'Courier New', 'Roboto Mono', monospace;
  font-size: 32px;
  font-weight: 700;
  color: #ff0033;
  letter-spacing: 4px;
  
  /* LED glow effect */
  text-shadow: 
    0 0 8px rgba(255, 0, 51, 0.8),
    0 0 16px rgba(255, 0, 51, 0.4),
    0 0 24px rgba(255, 0, 51, 0.2);
  
  /* Monospace alignment */
  font-variant-numeric: tabular-nums;
}

/* BPM Adjustment Buttons */
.bpm-controls {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.bpm-adjust-btn {
  width: 28px;
  height: 22px;
  background: var(--gradient-plastic-dark);
  border: 1px solid rgba(0, 0, 0, 0.8);
  border-radius: 3px;
  
  color: rgba(240, 240, 240, 0.6);
  font-size: 16px;
  font-weight: 700;
  
  cursor: pointer;
  transition: all 0.08s ease-out;
  
  box-shadow: var(--button-border-raised);
}

.bpm-adjust-btn:hover {
  background: var(--gradient-plastic-light);
  color: rgba(240, 240, 240, 0.9);
}

.bpm-adjust-btn:active {
  box-shadow: var(--button-border-pressed);
  transform: translateY(1px);
}

/* ========================================
   TRANSPORT CONTROLS
   ======================================== */

.transport-controls {
  display: flex;
  align-items: center;
  gap: 16px;
}

.transport-button {
  /* Additional spacing if needed */
}

.tap-button {
  /* Additional spacing if needed */
}

/* ========================================
   BEAT INDICATOR MODULE
   ======================================== */

.beat-indicator-module {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
}

.beat-led {
  width: 16px;
  height: 16px;
  border-radius: 50%;
  background: #1a1a1a;
  border: 2px solid rgba(0, 0, 0, 0.6);
  
  box-shadow: 
    inset 0 1px 2px rgba(0, 0, 0, 0.8),
    0 1px 1px rgba(255, 255, 255, 0.05);
  
  transition: all 0.05s ease-out;
}

.beat-led.active {
  background: var(--led-red-recording);
  box-shadow: 
    0 0 8px rgba(255, 0, 51, 0.8),
    0 0 16px rgba(255, 0, 51, 0.5),
    inset 0 1px 2px rgba(255, 255, 255, 0.2);
}

/* ========================================
   RESPONSIVE ADJUSTMENTS
   ======================================== */

@media (max-width: 768px) {
  .transport-bar {
    flex-wrap: wrap;
    justify-content: center;
    gap: 16px;
  }
  
  .divider {
    display: none;
  }
}
</style>
